class MathDojo(object):
	def __init__(self):
		self.val = 0
	def add(self,*e):
		list_sum = 0
		non_list_sum = 0
		for a in e:
			if type(a) == list:
				for h in a:
					list_sum += h
			else:
				non_list_sum += a
		self.val += list_sum+non_list_sum
		return self
	def subtract(self,*g):
		list2_sum = 0
		non_list2_sum = 0
		for a in g:
			if type(a) == list:
				for h in a:
					list2_sum += h
			else:
				non_list2_sum += a
		self.val -= list2_sum+non_list2_sum
		return self
	def result(self):
		print self.val

md = MathDojo()
md.add(1).add(1, 1, [1,1]).subtract(1,1,[1,1]).result()


