class MathDojo(object):
	def __init__(self):
		self.val = 0
	def add(self,*e):
		self.val += sum(e)
		return self
	def subtract(self,*g):
		self.val-= sum(g)
		return self
	def result(self):
		print self.val

md = MathDojo()
md.add(2).add(2,5).subtract(3,2).result()




